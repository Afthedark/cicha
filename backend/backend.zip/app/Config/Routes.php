<?php

use CodeIgniter\Router\RouteCollection;

/** @var RouteCollection $routes */

$routes->get('/', 'Home::index');

// OPTIONS catch-all for CORS preflights
$routes->options('(:any)', static function () {
    $response = service('response');
    $response->setHeader('Access-Control-Allow-Origin', '*');
    $response->setHeader('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization, X-Authorization, X-API-KEY, Access-Control-Request-Method');
    $response->setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PATCH, PUT, DELETE');
    return $response->setStatusCode(200);
});

// Group: API
$routes->group('api', static function ($routes) {
    
    // Auth Routes
    $routes->group('auth', static function ($routes) {
        $routes->post('login', 'AuthController::login');
        $routes->get('me', 'AuthController::me', ['filter' => 'jwt']);
        $routes->post('profile', 'AuthController::updateProfile', ['filter' => 'jwt']);
    });

    // Public Portal Routes (Visitante)
    $routes->group('public', static function ($routes) {
        $routes->get('home', 'PublicController::getHomeData');
        $routes->get('banners', 'PublicController::getBanners');
        $routes->get('institutional', 'PublicController::getInstitutional');
        $routes->get('articles', 'PublicController::getArticles');
        $routes->get('articles/(:segment)', 'PublicController::getArticleBySlug/$1');
        $routes->get('blogs', 'PublicController::getBlogs');
        $routes->get('blogs/(:segment)', 'PublicController::getBlogBySlug/$1');
        $routes->get('gallery', 'PublicController::getGallery');
        $routes->get('gallery/(:segment)', 'PublicController::getAlbumBySlug/$1');
        $routes->get('events', 'PublicController::getEvents');
        $routes->get('members', 'PublicController::getMembers');
        $routes->get('opportunities', 'PublicController::getOpportunities');
        $routes->get('b2b-meetings', 'PublicController::getB2BMeetings');
        $routes->get('b2b-meetings/(:segment)', 'PublicController::getB2BMeeting/$1');
        $routes->get('alliances', 'PublicController::getAlliances');
        $routes->get('settings', 'PublicController::getSettings');
        $routes->get('translations/el', 'PublicController::getGreekTranslations');
        $routes->get('translations/en', 'PublicController::getEnglishTranslations');
        $routes->post('contact', 'PublicController::submitContact');
        $routes->post('apply', 'PublicController::submitApplication');
    });

    // Exclusive Partner Portal Routes (Role: socio, admin, secretario)
    $routes->group('partner', ['filter' => ['jwt', 'role:admin,secretario,socio']], static function ($routes) {
        $routes->get('dashboard', 'PartnerController::dashboard');
        $routes->get('resources', 'PartnerController::getResources');
        $routes->post('resources/(:num)/download', 'PartnerController::downloadResource/$1');
        $routes->get('opportunities', 'PartnerController::getOpportunities');
        $routes->get('b2b-meetings', 'PartnerController::getB2BMeetings');
        $routes->get('b2b-meetings/(:segment)', 'PartnerController::getB2BMeetingDetail/$1');
        $routes->get('benefits', 'PartnerController::getBenefits');
        $routes->get('directory', 'PartnerController::getDirectory');
        $routes->get('categories', 'PartnerController::getCategories');
        // Actas de Socios (PDF / URL)
        $routes->get('minutes', 'PartnerController::getMinutes');
        $routes->post('minutes', 'PartnerController::createMinute');
        $routes->delete('minutes/(:num)', 'PartnerController::deleteMinute/$1');
        $routes->post('minutes/(:num)/download', 'PartnerController::downloadMinute/$1');
        // Subida de Documentos para Socios (PDF / Archivos de Actas hasta 30MB)
        $routes->post('upload', 'Admin\UploadController::uploadImage');
        // Decretos Oficiales (Consulta Socios)
        $routes->get('decrees', 'PartnerController::getDecrees');
        $routes->post('decrees/(:num)/download', 'PartnerController::downloadDecree/$1');
        // Boletín de Noticias para Socios
        $routes->get('news', 'PartnerController::getNews');
        $routes->get('news/(:segment)', 'PartnerController::getNewsDetail/$1');
    });

    // Database Auto-Migration (Secured via secret key parameter)
    $routes->get('admin/migrate', 'Admin\MigrationController::run');

    // Admin Content Management (Roles: admin, secretario)
    $routes->group('admin', ['filter' => ['jwt', 'role:admin,secretario']], static function ($routes) {
        $routes->get('dashboard', 'Admin\DashboardController::index');

        // Articles / News (Públicas)
        $routes->resource('articles', ['controller' => 'Admin\ArticlesController']);

        // Boletín de Noticias para Socios (Exclusivo)
        $routes->resource('partner-news', ['controller' => 'Admin\PartnerNewsController']);

        // B2B Meetings & Results (Reuniones B2B)
        $routes->resource('b2b-meetings', ['controller' => 'Admin\B2BMeetingsController']);

        // Blogs
        $routes->resource('blogs', ['controller' => 'Admin\BlogsController']);

        // Gallery / Photo Albums
        $routes->resource('gallery', ['controller' => 'Admin\GalleryController']);
        $routes->post('gallery/(:num)/photos', 'Admin\GalleryController::addPhoto/$1');
        $routes->delete('gallery/photos/(:num)', 'Admin\GalleryController::deletePhoto/$1');

        // Home Banners / Portadas
        $routes->resource('banners', ['controller' => 'Admin\BannersController']);

        // Events
        $routes->resource('events', ['controller' => 'Admin\EventsController']);

        // Members & Categories/Sectors
        $routes->resource('members', ['controller' => 'Admin\MembersController']);
        $routes->resource('categories', ['controller' => 'Admin\CategoriesController']);

        // Commercial Opportunities
        $routes->resource('opportunities', ['controller' => 'Admin\OpportunitiesController']);

        // Decrees (Admin CMS)
        $routes->resource('decrees', ['controller' => 'Admin\DecreesController']);

        // Exclusive Partner Resources & Benefits Management
        $routes->resource('partner-resources', ['controller' => 'Admin\PartnerResourcesController']);
        $routes->resource('partner-benefits', ['controller' => 'Admin\PartnerBenefitsController']);

        // Applications
        $routes->get('applications', 'Admin\ApplicationsController::index');
        $routes->get('applications/(:num)', 'Admin\ApplicationsController::show/$1');
        $routes->put('applications/(:num)', 'Admin\ApplicationsController::update/$1');
        $routes->delete('applications/(:num)', 'Admin\ApplicationsController::delete/$1');

        // Messages
        $routes->get('messages', 'Admin\MessagesController::index');
        $routes->get('messages/(:num)', 'Admin\MessagesController::show/$1');
        $routes->put('messages/(:num)', 'Admin\MessagesController::update/$1');
        $routes->delete('messages/(:num)', 'Admin\MessagesController::delete/$1');

        // Authorities / Board
        $routes->resource('authorities', ['controller' => 'Admin\AuthoritiesController']);

        // Institutional Sections
        $routes->resource('institutional', ['controller' => 'Admin\InstitutionalController']);

        // Greek Translations (CMS Administrable)
        $routes->post('translations/batch', 'Admin\GreekTranslationsController::updateBatch');
        $routes->resource('translations', ['controller' => 'Admin\GreekTranslationsController']);

        // Alliances
        $routes->resource('alliances', ['controller' => 'Admin\AlliancesController']);

        // Settings
        $routes->get('settings', 'Admin\SettingsController::index');
        $routes->post('settings', 'Admin\SettingsController::updateAll');

        // Uploads
        $routes->post('upload', 'Admin\UploadController::uploadImage');

        // Users Management (Role permissions enforced internally in UsersController)
        $routes->resource('users', ['controller' => 'Admin\UsersController']);
    });
});
